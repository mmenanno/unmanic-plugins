
**<span style="color:#56adda">0.0.4</span>**
- generalized use of stream tags for audio and video streams too

**<span style="color:#56adda">0.0.3</span>**
- add test to check attachment streams tags

**<span style="color:#56adda">0.0.2</span>**
- fix __init__.py filename

**<span style="color:#56adda">0.0.1</span>**
- Initial version
