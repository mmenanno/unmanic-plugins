
:::warning
Modifying a video's length may result in unintended issues.
For example, a file containing subtitle streams may lose the correct time sync for the subtitles.
Ensure that you understand this before continuing.
:::
