
---

#### Description:

This Plugin will convert hev1 HEVC to Apple-compatible hvc1 HEVC.

Faststart is also applied by default but can be disabled.

---
###### Note:
This plugin was developed with ffmpeg version 5.1.3-Jellyfin - it may not work with other versions.
